<?php
session_start();
require_once ('process/dbh.php');
$atten_id = $_POST['atten_id'];
$query = "delete from attendance where atten_id='$atten_id'";
$ex = mysqli_query($conn, $query);
header("location: ..//attendance_view.php");
?>