<?php
session_start();
require_once ('process/dbh.php');
$aid=$_SESSION['id'];
$emp_id = $_POST['emp_id'];
$salary = $_POST['salary'];
$allowance = $_POST['allowance'];
$deduction = $_POST['deduction'];
$total = $_POST['total'];
$date = date('Y-m-d');
 $sql = "INSERT INTO `salary`(`sal_id`, `aid`, `id`, `salary`, `allowance` , `deduction`, `total`, `date`) VALUES 
 (NULL, '$aid', '$emp_id' , '$salary' , '$allowance', '$deduction' , '$total', '$date')";
//die();
$result = mysqli_query($conn, $sql);

if(($result) == 1){    
    header("Location:addsalary.php");
}
else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Assign')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

?>