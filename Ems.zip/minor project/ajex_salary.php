<?php
        include("process/dbh.php");	
		$sal = $_POST['emp_id'];
		$query = "select * from basic_salary where id=$sal";
		//die();
		$ex = mysqli_query($conn, $query);	
		while($row=mysqli_fetch_assoc($ex))
		{	
	//echo $row['salary'];
	?>
	<option value="<?php echo $row['base']?>"><?php echo $row['base']?></option>
	
			<!--<input type="number" value="<?php echo $row['base'];?>">	-->
	  
<?php	
	}										
?>