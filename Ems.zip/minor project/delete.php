<?php
//including the database connection file
include("process/dbh.php");

//getting id of the data from url
$id = $_POST['id'];

//deleting the row from table
$result = mysqli_query($conn, "DELETE FROM employee WHERE id=$id");
//die();
//redirecting to the display page (index.php in our case)
header("Location:viewemp.php");
?>

