<?php
session_start();
require_once ('process/dbh.php');
$aid = $_SESSION['id'];
$id = $_POST['id'];
$atten_id = $_POST['atten_id'];
$attendance = $_POST['attendance'];
$date = date('Y-m-d');

$query = "update attendance set aid='$aid',id='$id',attendance='$attendance',date='$date' where atten_id='$atten_id'";
//die();

$result = mysqli_query($conn, $query);

if(($result) == 1){    
/*echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Update Successfully')
    </SCRIPT>");*/
    header("Location: ..//attendance_view.php");
   //echo "Successful";
}
else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to update')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
	//echo "Fail";
}
?>