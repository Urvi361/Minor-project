<?php

session_start();
?>
<html>
<head>
	<title>Salary Table | Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
		<link href="menu.css" rel="stylesheet" media="all">
		<?php
			 $rowperpage = 10;
            $row = 0;
            // Previous Button
            if(isset($_POST['but_prev'])){
                $row = $_POST['row'];
                $row -= $rowperpage;
                if( $row < 0 ){
                    $row = 0;
                }
            }
            // Next Button
            if(isset($_POST['but_next'])){
                $row = $_POST['row'];
                $allcount = $_POST['allcount'];

                $val = $row + $rowperpage;
                if( $val < $allcount ){
                    $row = $val;
                }
            }
		?>
</head>
<body>	
<header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">View specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve leave</a>
					<a href="cancelleave.php">Cancel leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Employee Salary Record
<input id="gfg" type="text" placeholder="Search here" style="margin-left:1100px"></h2>
	<table>
	<thead>
			<tr>
			<th align = "center">Sr.No</th>
				<th align = "center">Name</th>
				
				<th align = "center">salary</th>
				<th align = "center">allowance</th>
				<th align = "center">deduction</th>
				<th align = "center">TotalSalary</th>
				<th align = "center">Date</th>
				<th align = "center">View</th>
			</tr>
		</thead>	
			<?php
			require_once ('process/dbh.php');
			//COunt the number of rows
			$sql1 = "SELECT COUNT(sal_id) AS cntrows FROM salary";
            $result1 = mysqli_query($conn,$sql1);
            $fetchresult = mysqli_fetch_array($result1);
            $allcount = $fetchresult['cntrows'];
			
			$sql ="select * from salary as s
			left join employee as e on s.id = e.id where 
			s.aid='".$_SESSION['id']."'limit $row,".$rowperpage;
			//$sql = "SELECT id,salary,allowance,deduction,total,date from salary where aid='".$_SESSION['id']."'";
			$result = mysqli_query($conn, $sql);
			$c=$row;
			while ($row = mysqli_fetch_assoc($result)){
			$c++;
			?>
			<tbody id="geeks">
			
				<tr>
				<td><?php echo $c; ?></td>
				<td><?php echo $row['firstName'];?> <?php echo $row['lastName'];?> </td>	
				<td><?php echo $row['salary']; ?></td>
				<td><?php echo $row['allowance']; ?></td>
				<td><?php echo $row['deduction']; ?></td>
				<td><?php echo $row['total']; ?></td>
				<td><?php echo $row['date']; ?></td>
					
				<td> </a>
				
				<form action="view_salary.php" method="post">
					<input type="hidden" name="sal_id" value="<?php echo $row['sal_id'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">View</button></p>
					</form>
				</tr>
				</tbody>
			<?php
				}
			?>
			
			</table>
			</div>
			 <form method="post" action="">
            <div id="div_pagination">
                <input type="hidden" name="row" value="<?php echo $row; ?>">
                <input type="hidden" name="allcount" value="<?php echo $allcount; ?>">
                <input type="submit" class="button" name="but_prev" value="Previous">
                <input type="submit" class="button" name="but_next" value="Next">
            </div>
        </form>
</body>
  <script src="js/js/jquery.min.js"></script>
  <script src="js/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/js/popper.min.js"></script>
  <script src="js/js/bootstrap.min.js"></script>
  <script src="js/js/jquery.easing.1.3.js"></script>
  <script src="js/js/jquery.waypoints.min.js"></script>
  <script src="js/js/jquery.stellar.min.js"></script>
  <script src="js/js/jquery.animateNumber.min.js"></script>
  <script src="js/js/owl.carousel.min.js"></script>
  <script src="js/js/jquery.magnific-popup.min.js"></script>
  <script src="js/js/scrollax.min.js"></script>
  <script src="js/js/main.js"></script>
<script> 
            $(document).ready(function() { 
                $("#gfg").on("keyup", function() { 
                    var value = $(this).val().toLowerCase(); 
                    $("#geeks tr").filter(function() { 
                        $(this).toggle($(this).text() 
                        .toLowerCase().indexOf(value) > -1) 
                    }); 
                }); 
            }); 
        </script> 
</html>