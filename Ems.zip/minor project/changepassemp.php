<?php
session_start();
require_once ('process/dbh.php');
$id=$_SESSION['id'];

if(isset($_POST['update']))
{
   $old = $_POST['oldpass'];
   $new = $_POST['newpass'];
   $con = $_POST['conpass'];

  $query="select password from employee WHERE id='$id'";
// die();
 $result = mysqli_query($conn, $query);

  while($row = mysqli_fetch_assoc($result))
{
	if($row['password'] != $old)
	{
		echo "Enter Correct Password";
	}
	if($new != $con)
	{
		echo "Enter Correct Password  ";
	}
	if($row['password'] == $old && $new == $con)
	{
		$q="UPDATE `employee` SET `password`='$con' WHERE id = $id";
	//die();
		$e=mysqli_query($conn, $q);
		echo ("<SCRIPT LANGUAGE='JavaScript'>
                  window.alert('Password Updated')
                window.location.href='myprofile.php';</SCRIPT>");
	}
	
	 else{
          echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Update Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
        }
	
}
  
  /*$result = mysqli_query($conn, "select employee.password from employee WHERE id='".$_SESSION['id']."'");
     $employee = mysqli_fetch_assoc($conn, $result);
          if($old == $employee['password']){
            $sql = "UPDATE `employee` SET `password`='$new' WHERE id = $id";
            mysqli_query($conn, $sql);
             echo ("<SCRIPT LANGUAGE='JavaScript'>
                  window.alert('Password Updated')
                window.location.href='myprofile.php?id=$id';</SCRIPT>"); 
          
        }

        else{
          echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Update Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
        }*/

  
}
?>





<html>
<head>
  <title>Change Password | Employee Managment System</title>
  <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet">
	<link href="menu.css" rel="stylesheet">
</head>
<body>
  <header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
  
  <div class="divider"></div>
  

    <!-- <form id = "registration" action="edit.php" method="POST"> -->
  <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Update Password</h2>
					
					
                    <form id = "registration" action="changepassemp.php" method="POST">

                          <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                  <p>Old Password</p>
                                     <input class="input--style-1" type="Password" name = "oldpass" required >
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                  <p>New Password</p>
                                    <input class="input--style-1" type="Password" name="newpass" required>
                                </div>
                            </div>
							<div class="col-2">
                                <div class="input-group">
                                  <p>Confirm Password</p>
                                    <input class="input--style-1" type="Password" name="conpass" required>
                                </div>
                            </div>
                        </div>

                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit" name="update">Submit</button>
                        </div>
                        
                    </form>
                    
            </div>
        </div>
    </div>


</body>
</html>
