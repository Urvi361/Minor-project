<!DOCTYPE html>
<?php
session_start();
?>
<html>
<head>
    <!-- Title Page-->
    <title>Salary print | Employee Panel</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	<link href="css/menu.css" rel="stylesheet" media="all">
</head>

<body>
 
	
<!--<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="#">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="#">Add attendance</a>
					<a href="#">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="#">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>
    </header/>
    -->
    <div class="divider"></div>

    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
				<?php
				include("process/dbh.php");
				$sal_id=$_POST['sal_id'];
				//die();
				$sql ="select * from salary as s
				left join employee as e on s.id = e.id where 
				sal_id='$sal_id'";
				$result = mysqli_query($conn, $sql);
				$row = mysqli_fetch_assoc($result)
				?>
                    <h2 class="title">Salary Info</h2>
					
                    <form method="POST">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                     First Name:<input class="input--style-1" value="<?php echo $row['firstName']?>" readonly>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    Last Name:<input class="input--style-1" value="<?php echo $row['lastName']?>" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="input-group">
                            Salary:<input class="input--style-1" value="<?php echo $row['salary']?>" readonly>
                        </div>
                        
                         <div class="input-group">
                            Allowance:<input class="input--style-1" value="<?php echo $row['allowance']?>" readonly>
                        </div>

                        <div class="input-group">
                            Deduction:<input class="input--style-1" value="<?php echo $row['deduction']?>" readonly>
                        </div>

                        <div class="input-group">
                            Total:<input class="input--style-1" value="<?php echo $row['total']?>" readonly>
                        </div>
						 <div class="input-group">
                            Date:<input class="input--style-1" value="<?php echo $row['date']?>" readonly>
                        </div>

                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit" onclick="print_current_page()">Print</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
<script>
function print_current_page()
{
window.print();
}
</script>
</body>

</html>
<!-- end document-->
