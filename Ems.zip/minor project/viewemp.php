<?php
session_start();
?>

<html>
<head>
	<title>View Employee |  Admin Panel | Employee Managment System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link rel="stylesheet" type="text/css" href="menu.css">
	<script src= "https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">  </script>
    
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
	<?php $rowperpage = 10;
            $row = 0;

            // Previous Button
            if(isset($_POST['but_prev'])){
                $row = $_POST['row'];
                $row -= $rowperpage;
                if( $row < 0 ){
                    $row = 0;
                }
            }

            // Next Button
            if(isset($_POST['but_next'])){
                $row = $_POST['row'];
                $allcount = $_POST['allcount'];

                $val = $row + $rowperpage;
                if( $val < $allcount ){
                    $row = $val;
                }
            }
?>
	</head>

<body>
	<header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">View specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve leave</a>
					<a href="cancelleave.php">Cancel leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	 <div class="divider"></div>
	<div id="divimg">
		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Empolyee Details 
		
		
    	<table style="width:100%">
		<!--<input type="text"  placeholder="Search for names..">-->
		<thead>
			<tr>

				<th align = "center">Serial No.</th>
				<th align = "center">Picture</th>
				<th align = "center">Name</th>
				<th align = "center">Email</th>
				<th align = "center">Birthday</th>
				<th align = "center">Gender</th>
				<th align = "center">Contact</th>
			
				<th align = "center">Address</th>
				<th align = "center">Department</th>
				<th align = "center">Degree</th>
				<th align = "center">Salary</th>
				<th align = "center">Status</th>
				
				
				<th align = "center">Options</th>
			</tr>
			</thead>
			<tbody>
			<?php
			require_once ('process/dbh.php');
			//$sql = "SELECT * from employee as e left join basic_salary as s on e.id= s.id WHERE aid='".$_SESSION['id']."'";
			$sql ="select * from employee as e
			left join basic_salary as b on e.id = b.id where
			b.aid='".$_SESSION['id']."'";
			$cnt=0;
			//echo "$sql";
			$result = mysqli_query($conn, $sql);
				while ($employee = mysqli_fetch_assoc($result)){
					$cnt++;
					
					echo "<tr>";
					echo "<td>".$cnt."</td>";
					echo "<td><img src='process/".$employee['pic']."' height = 60px width = 60px></td>";
					echo "<td>".$employee['firstName']." ".$employee['lastName']."</td>";
					
					echo "<td>".$employee['email']."</td>";
					echo "<td>".$employee['birthday']."</td>";
					echo "<td>".$employee['gender']."</td>";
					echo "<td>".$employee['contact']."</td>";
					echo "<td>".$employee['address']."</td>";
					echo "<td>".$employee['dept']."</td>";
					echo "<td>".$employee['degree']."</td>";
					echo "<td>".$employee['base']."</td>";
					echo "<td>".$employee['status']."</td>";
echo "<td>"
?>
<form action="edit.php" method="post">
					<input type="hidden" name="id" value="<?php echo $employee['id'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">Edit</button></p>
				</form>
				<form action="delete.php" method="post">
					<input type="hidden" name="id" value="<?php echo $employee['id'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">Delete</button></p>
				</form>
		<?php	
				echo "</td>";
					//echo "<td><a href=\"edit.php?id=$employee[id]\">Edit</a> | <a href=\"delete.php?id=$employee[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
echo "</tr>";

				}


			?>
			</tbody>

		</table>
		</div>

</body>
</html>
