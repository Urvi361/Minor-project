<?php
session_start();
require_once ('process/dbh.php');
//$id = (isset($_GET['id']) ? $_GET['id'] : '');
$pid = $_POST['pid'];
//die();
//$id = $_GET['id'];
$date = date('Y-m-d');
//echo "$date";
$sql = "UPDATE `project` SET `subdate`='$date',`pstatus`='Completed' WHERE pid = '$pid'";
//die();
$result = mysqli_query($conn , $sql);
header("Location: empproject.php");
?>