<?php
session_start();
require_once ('process/dbh.php');

if(isset($_POST['update']))
{

  $id = mysqli_real_escape_string($conn, $_POST['id']);
  
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  
  $contact = mysqli_real_escape_string($conn, $_POST['contact']);
  $address = mysqli_real_escape_string($conn, $_POST['address']);
 
 $result = mysqli_query($conn, "UPDATE `employee` SET `email`='$email',`contact`='$contact',`address`='$address' WHERE id='".$_SESSION['id']."'");

 echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated')
    window.location.href='myprofile.php';
    </SCRIPT>");

  
}
?>
<html>
<head>
  <title>Update Profile | Employee Managment System</title>
  <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
	 <link href="menu.css" rel="stylesheet" media="all">
</head>
<body>
  <header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
  
  <div class="divider"></div>
  

    <!-- <form id = "registration" action="edit.php" method="POST"> -->
  <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Update Info</h2>
					
					<?php
					require_once ('process/dbh.php');
				
					$query=" select * from employee where id='".$_SESSION['id']."'";
					$res1 = mysqli_query($conn, $query);
					$row = mysqli_fetch_assoc($res1);
					
					?>
                    <form id = "registration" action="myprofileup.php" method="POST">



                        <div class="input-group">
                          <p>Email</p>
                            <input class="input--style-1" type="email"  name="email" value="<?php echo $row['email'];?>">
                        </div>
                       
                        
                        <div class="input-group">
                          <p>Contact</p>
                            <input class="input--style-1" type="number" name="contact" value="<?php echo $row['contact'];?>">
                        </div>

                         <div class="input-group">
                          <p>Address</p>
                            <input class="input--style-1" type="text"  name="address" value="<?php echo $row['address'];?>">
                        </div>

                       
                        <input type="hidden" name="id" id="textField" value="<?php echo $row['id'];?>" required="required"><br><br>
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit" name="update">Submit</button>
                        </div>
                        
                    </form>
                   <!-- <br>
                    <button class="btn btn--radius btn--green" onclick="window.location.href = 'changepassemp.php?id=<?php echo $row['id']?>';">Change Password</button>
            -->    </div>
            </div>
        </div>
    </div>


</body>
</html>
