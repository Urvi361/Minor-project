<?php
session_start();
?>
<html>
<head>
	<title>Employee Leave | Admin Panel | Employee managment system</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link href="menu.css" rel="stylesheet" type="text/css">
</head>
<body>
	
	  <header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">View specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve leave</a>
					<a href="cancelleave.php">Cancel leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	
	 
	<div class="divider"></div>
	<div id="divimg">
	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Employee Cancelled Leave Details</h2>

		<table>
			<tr>
				<th>Serial No.</th>
				
				<th>Name</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Total Days</th>
				<th>Reason</th>
				<th>Status</th>
			<!--	<th>Options</th>-->
			</tr>

			<?php
			require_once ('process/dbh.php');

			//$sql = "SELECT * from `employee_leave`";
			$sql = "Select employee.id, employee.firstName, employee.lastName, employee_leave.start, employee_leave.end, employee_leave.reason, employee_leave.status, employee_leave.token From employee left join employee_leave on employee.id = employee_leave.id Where (employee_leave.aid='".$_SESSION['id']."' and employee_leave.status='Cancelled') order by employee_leave.token";
			$result = mysqli_query($conn, $sql);
			$cnt=0;
				while ($employee = mysqli_fetch_assoc($result)){
				$cnt++;
				$date1 = new DateTime($employee['start']);
				$date2 = new DateTime($employee['end']);
				$interval = $date1->diff($date2);
				$interval = $date1->diff($date2);
				//echo "difference " . $interval->days . " days ";

					echo "<tr>";
					//echo "<td>".$employee['id']."</td>";
					echo "<td>".$cnt."</td>";
					echo "<td>".$employee['firstName']." ".$employee['lastName']."</td>";
					
					echo "<td>".$employee['start']."</td>";
					echo "<td>".$employee['end']."</td>";
					echo "<td>".$interval->days."</td>";
					echo "<td>".$employee['reason']."</td>";
					echo "<td>".$employee['status']."</td>";
				//	echo "<td><a href=\"approve.php?id=$employee[id]&token=$employee[token]\"  onClick=\"return confirm('Are you sure you want to Approve the request?')\">Approve</a> | <a href=\"cancel.php?id=$employee[id]&token=$employee[token]\" onClick=\"return confirm('Are you sure you want to Canel the request?')\">Cancel</a></td>";

				}


			?>

		</table>
		
	</div>
</body>
</html>