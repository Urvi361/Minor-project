<?php
session_start();
require_once ('process/dbh.php');
//echo $eid = $_SESSION['eid'];
if(isset($_POST['submit']))
$pid = $_POST['pid'];
$date = date('Y-m-d');

//File upload code
$files = $_FILES['file'];
$filename = $files['name'];
$filrerror = $files['error'];
$filetemp = $files['tmp_name'];
$fileext = explode('.', $filename);
$filecheck = strtolower(end($fileext));
$fileextstored = array('png' , 'jpg' , 'pdf', 'docx');

if(in_array($filecheck, $fileextstored))
{
    $destinationfile = 'uploads/'.$filename;  
 move_uploaded_file($filetemp, $destinationfile);
echo $sql = "UPDATE `project` SET `subdate`='$date',`status`='Submitted',`path`='$path' WHERE pid = '$pid';";
die();
$update = mysqli_query($conn ,$sql);

}
}
?>