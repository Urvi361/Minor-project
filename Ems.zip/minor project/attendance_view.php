<?php
session_start();
?>
<html>
<head>
	<title>Attendance |  Admin Panel | Employee Managment System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link href="menu.css" rel="stylesheet" type="text/css">
	<?php
			 $rowperpage = 10;
            $row = 0;
            // Previous Button
            if(isset($_POST['but_prev'])){
                $row = $_POST['row'];
                $row -= $rowperpage;
                if( $row < 0 ){
                    $row = 0;
                }
            }
            // Next Button
            if(isset($_POST['but_next'])){
                $row = $_POST['row'];
                $allcount = $_POST['allcount'];

                $val = $row + $rowperpage;
                if( $val < $allcount ){
                    $row = $val;
                }
            }
		?>
</head>
<body>
	
    <header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">View specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve leave</a>
					<a href="cancelleave.php">Cancel leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	
	
	<div class="divider"></div>
	<div id="divimg">
<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Employee Attendance Record
</h2>
		<table>
			<tr>
				<th align = "center">Number</th>
				<!--<th align = "center">Picture</th>-->
				<th align = "center">Name</th>
				<th align = "center">Department</th>
				<th align = "center">Attendance</th>
				<th align = "center">Date</th>
				<th align = "center">Action</th>
			</tr>

		
			<?php
			require_once ('process/dbh.php');
			$sql1 = "SELECT COUNT(atten_id) AS cntrows FROM attendance";
            $result1 = mysqli_query($conn,$sql1);
            $fetchresult = mysqli_fetch_array($result1);
            $allcount = $fetchresult['cntrows'];
			
			$sql ="select * from attendance as a
			left join employee as e on a.id = e.id where
			a.aid='".$_SESSION['id']."' order by date desc limit $row,".$rowperpage;
			//SELECT * FROM `attendance` WHERE  date between  DATE_FORMAT(CURDATE() ,'%Y-%m-01') AND CURDATE()
			$result = mysqli_query($conn, $sql);
			//$cnt=0;
			$sno = $row;
				while ($row = mysqli_fetch_assoc($result)) {
					$sno++;
					echo "<tr>";
					echo "<td>".$sno."</td>";
				//	echo "<td><img src='process/".$row['pic']."' height = 60px width = 60px></td>";
					echo "<td>".$row['firstName']." ".$row['lastName']."</td>";
					echo "<td>".$row['dept']."</td>";
					echo "<td>".$row['attendance']."</td>";
					echo "<td>".$row['date']."</td>";
				//	echo "<td><a href=\"attendance_edit.php?id=$row[atten_id]\">Edit</a> | <a href=\"attendance_delete.php?id=$row[atten_id]\" onClick=\"return confirm('Are you sure you want to delete the attendance?')\">Delete</a></td>";
echo "<td>"
?>
<form action="attendance_edit.php" method="post">
					<input type="hidden" name="atten_id" value="<?php echo $row['atten_id'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">Edit</button></p>
				</form>
				
				<form action="attendance_delete.php" method="post">
					<input type="hidden" name="atten_id" value="<?php echo $row['atten_id'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">Delete</button></p>
				</form>
		<?php	
				echo "</td>";
				}


			?>

		</table>
		
	</div>
	 <form method="post" action="">
            <div id="div_pagination">
                <input type="hidden" name="row" value="<?php echo $row; ?>">
                <input type="hidden" name="allcount" value="<?php echo $allcount; ?>">
                <input type="submit" class="button" name="but_prev" value="Previous">
                <input type="submit" class="button" name="but_next" value="Next">
            </div>
        </form>
</body>

</html>