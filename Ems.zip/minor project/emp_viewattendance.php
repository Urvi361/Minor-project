<?php
session_start();
?>
<html>
<head>
	<title>Attendance |  Employee Panel | Employee Managment System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link href="menu.css" rel="stylesheet" type="text/css">
	<?php
			 $rowperpage = 10;
            $row = 0;
            // Previous Button
            if(isset($_POST['but_prev'])){
                $row = $_POST['row'];
                $row -= $rowperpage;
                if( $row < 0 ){
                    $row = 0;
                }
            }
            // Next Button
            if(isset($_POST['but_next'])){
                $row = $_POST['row'];
                $allcount = $_POST['allcount'];

                $val = $row + $rowperpage;
                if( $val < $allcount ){
                    $row = $val;
                }
            }
		?>
</head>
<body>
	<header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
	
	<div class="divider"></div>
	<div id="divimg">
<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Attendance Record</h2>

		<table>
			<tr>

				<th align = "center">Number</th>
				<!--<th align = "center">Picture</th>
				<th align = "center">Name</th>
				<th align = "center">Department</th>-->
				<th align = "center">Attendance</th>
				<th align = "center">Date</th>
				<!--<th align = "center">Action</th>-->
			</tr>

			<?php
			require_once ('process/dbh.php');
			$sql1 = "SELECT COUNT(id) AS cntrows FROM attendance where id='".$_SESSION['id']."'";
            $result1 = mysqli_query($conn,$sql1);
            $fetchresult = mysqli_fetch_array($result1);
            $allcount = $fetchresult['cntrows'];
			
			$sql ="select * from attendance as a
			left join employee as e on a.id = e.id where
			a.id='".$_SESSION['id']."'";
			//SELECT * FROM `attendance` WHERE  date between  DATE_FORMAT(CURDATE() ,'%Y-%m-01') AND CURDATE()
			$result = mysqli_query($conn, $sql);
			$cnt=$row;
				while ($row = mysqli_fetch_assoc($result)) {
					$cnt++;
					echo "<tr>";
					echo "<td>".$cnt."</td>";
					//echo "<td><img src='process/".$row['pic']."' height = 60px width = 60px></td>";
					//echo "<td>".$row['firstName']." ".$row['lastName']."</td>";
					//echo "<td>".$row['dept']."</td>";
					echo "<td>".$row['attendance']."</td>";
					echo "<td>".$row['date']."</td>";
					//echo "<td><a href=\"attendance_edit.php?id=$row[atten_id]\">Edit</a> | <a href=\"attendance_delete.php?id=$row[atten_id]\" onClick=\"return confirm('Are you sure you want to delete the attendance?')\">Delete</a></td>";

				}


			?>

		</table>
		
	</div>
	 <form method="post" action="">
            <div id="div_pagination">
                <input type="hidden" name="row" value="<?php echo $row; ?>">
                <input type="hidden" name="allcount" value="<?php echo $allcount; ?>">
                <input type="submit" class="button" name="but_prev" value="Previous">
                <input type="submit" class="button" name="but_next" value="Next">
            </div>
        </form>
</body>
</html>