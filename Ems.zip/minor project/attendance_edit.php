<?php
session_start();
?>

<html>
<head>
	   <!-- Title Page-->
    <title>Attendance | Admin Panel</title>
    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
	 <link href="css/main.css" rel="stylesheet" media="all">
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link href="menu.css" rel="stylesheet" type="text/css">
	
</head>
<body>
<header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">Record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">Specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve</a>
					<a href="cancelleave.php">Cancel</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	
	<div class="divider"></div>
    <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Attendance</h2>
	
<form action="attendance_update.php" method="POST" enctype="multipart/form-data">
                      
               	

                <?php
			    include("process/dbh.php");		
				$atten_id = $_POST['atten_id'];
				$sql ="select * from attendance as a
				left join employee as e on a.id = e.id where 
				atten_id='$atten_id'";
				//die();
				$ex = mysqli_query($conn, $sql);	
			   $row=mysqli_fetch_assoc($ex)
			 
			    ?>
				 <div>
                    <input type="hidden" name="atten_id" value="<?php echo $row['atten_id']?>" readonly>
                 </div>
				  <div>
                    <input type="hidden" name="id" value="<?php echo $row['id']?>" readonly>
                 </div>
				 <div class="row row-space">
                    <div class="col-2">
                        <div class="input-group">
                            First Name:<input class="input--style-1" value="<?php echo $row['firstName']?>" readonly>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="input-group">
                            Last Name:<input class="input--style-1" value="<?php echo $row['lastName']?>" readonly>
                        </div>
                    </div>
                 </div>
				 
                 <div class="input-group">
                    <div class="rs-select2 js-select-simple select--no-search">
                        <select name="attendance">
                            <option disabled="disabled" selected="selected">Attendance</option>
                                <option value="present">Present</option>
                                <option value="absent">Absent</option>
                                <option value="onleave">On leave</option>
                        </select>
                           <div class="select-dropdown"></div>
                    </div>
                 </div>
                    
         
                     <!--   <div class="input-group">
                            <input class="input--style-1" type="hidden" name="id">
                        </div>-->
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Update</button>
                        </div>
                    </form>
					  </div>
            </div>
        </div>
    </div>
		  <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

	
</body>
</html>