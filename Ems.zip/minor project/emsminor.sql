-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2020 at 09:29 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `emsminor`
--

-- --------------------------------------------------------

--
-- Table structure for table `alogin`
--

CREATE TABLE IF NOT EXISTS `alogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` tinytext NOT NULL,
  `password` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `alogin`
--

INSERT INTO `alogin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Reeya Patel', 'admin', 'admin'),
(2, 'kenil', 'kenil123@gmail.com', 'kenil@84'),
(3, 'Jhanvi', 'jhanvi11@gmail.com', 'Jhanvi123');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `atten_id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `attendance` varchar(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`atten_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`atten_id`, `aid`, `id`, `attendance`, `date`) VALUES
(11, 1, 113, 'present', '2020-04-10'),
(12, 1, 116, 'present', '2020-04-10'),
(13, 1, 118, 'onleave', '2020-04-10'),
(14, 1, 113, 'onleave', '2020-04-09'),
(15, 1, 116, 'present', '2020-04-09'),
(16, 1, 118, 'present', '2020-04-09');

-- --------------------------------------------------------

--
-- Table structure for table `basic_salary`
--

CREATE TABLE IF NOT EXISTS `basic_salary` (
  `aid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `base` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `basic_salary`
--

INSERT INTO `basic_salary` (`aid`, `id`, `base`) VALUES
(1, 113, 35000),
(1, 116, 50000),
(1, 118, 25000);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `dept` varchar(100) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `pic` text NOT NULL,
  `status` int(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=122 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `aid`, `firstName`, `lastName`, `email`, `password`, `birthday`, `gender`, `contact`, `address`, `dept`, `degree`, `pic`, `status`) VALUES
(113, 1, 'kenil', 'vavaliya', '17se02ce062@ppsu.ac.in', '1234', '2000-01-20', 'Male', '9664983466', 'Surat', 'CE', 'B. Tech', 'images/no.jpg', 1),
(114, 2, 'darshan', 'chovatiya', 'darshanchovatiya@gmail.com', '1234', '2000-03-07', 'Male', '7569824365', 'Surat', 'IT', 'B. Tech', 'images/no.jpg', 1),
(115, 2, 'reeya', 'patel', '18se09ce003@ppsu.ac.in', '1234', '1999-02-05', 'Female', '9658341238', 'Jakat naka', 'HR', 'MBA', 'images/no.jpg', 1),
(116, 1, 'jhanvi', 'mehta', '18se09ce001@ppsu.ac.in', '1234', '1997-10-06', 'Female', '9658312238', 'Ankleshwar', 'Admin', 'MBA', 'images/no.jpg', 1),
(117, 3, 'Pratik', 'patel', '17se02ce043@ppsu.ac.in', '1234', '1998-01-14', 'Male', '9586674235', 'Amroli', 'CE', 'B. Tech', 'images/no.jpg', 1),
(118, 1, 'Jay', 'Thakkar', '17se02ce059@ppsu.ac.in', '1234', '1999-07-17', 'Male', '7569853553', 'Adajan', 'CE', 'B. Tech', 'images/no.jpg', 1),
(119, 2, 'Mahek', 'Vasoya', '17se02ce061@ppsu.ac.in', '1234', '1998-07-08', 'Male', '7952369875', 'Katargam', 'IT', 'B. Tech', 'images/no.jpg', 1),
(120, 3, 'Chandresh', 'Maniya', '17se02ce035@ppsu.ac.in', '1234', '1999-08-10', 'Male', '9642358715', 'Mota varachha', 'IT', 'BCA', 'images/no.jpg', 1),
(121, 3, 'Vrajesh', 'Bhatt', '17se02ce005@ppsu.ac.in', '1234', '1999-03-09', 'Male', '9824356982', 'Kamrej', 'CE', 'BCA', 'images/no.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee_leave`
--

CREATE TABLE IF NOT EXISTS `employee_leave` (
  `id` int(11) DEFAULT NULL,
  `aid` int(11) NOT NULL,
  `token` int(11) NOT NULL AUTO_INCREMENT,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `reason` char(100) DEFAULT NULL,
  `status` char(50) DEFAULT NULL,
  PRIMARY KEY (`token`),
  KEY `employee_leave_ibfk_1` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=320 ;

--
-- Dumping data for table `employee_leave`
--

INSERT INTO `employee_leave` (`id`, `aid`, `token`, `start`, `end`, `reason`, `status`) VALUES
(113, 1, 318, '2020-04-11', '2020-04-12', 'Sick Leave', 'Approved'),
(118, 1, 319, '2020-04-11', '2020-04-13', 'Tour', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL,
  `eid` int(11) DEFAULT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `subdate` date DEFAULT '0000-00-00',
  `mark` int(11) NOT NULL,
  `pstatus` varchar(50) DEFAULT NULL,
  `path` varchar(100) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `project_ibfk_1` (`eid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=235 ;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`pid`, `aid`, `eid`, `pname`, `duedate`, `subdate`, `mark`, `pstatus`, `path`) VALUES
(233, 1, 113, 'QBC application development', '2020-05-02', '0000-00-00', 0, 'Due', ''),
(234, 1, 116, 'online exam php', '2020-04-29', '0000-00-00', 0, 'Due', '');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE IF NOT EXISTS `salary` (
  `sal_id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `salary` int(11) NOT NULL,
  `allowance` int(11) NOT NULL,
  `deduction` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`sal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`sal_id`, `aid`, `id`, `salary`, `allowance`, `deduction`, `total`, `date`) VALUES
(4, 1, 113, 25000, 2000, 500, 26500, '2020-04-10'),
(5, 1, 116, 50000, 5000, 0, 55000, '2020-04-10');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee_leave`
--
ALTER TABLE `employee_leave`
  ADD CONSTRAINT `employee_leave_ibfk_1` FOREIGN KEY (`id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`eid`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
