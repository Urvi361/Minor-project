<?php

session_start();
?>
<html>
<head>
	<title>Salary Table | Employee Panel</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
		<link href="menu.css" rel="stylesheet" media="all">
</head>
<body>	<header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Salary Record</h2>

	<table>
			<tr>
			<th align = "center">Sr.No</th>
				<th align = "center">Name</th>
				
				<th align = "center">salary</th>
				<th align = "center">allowance</th>
				<th align = "center">deduction</th>
				<th align = "center">TotalSalary</th>
				<th align = "center">Date</th>
				<th align = "center">View</th>
			</tr>
			
			<?php
			require_once ('process/dbh.php');
			$sql ="select * from salary as s
			left join employee as e on s.id = e.id where 
			s.id='".$_SESSION['id']."'";
			//$sql = "SELECT id,salary,allowance,deduction,total,date from salary where aid='".$_SESSION['id']."'";
			$result = mysqli_query($conn, $sql);
			$c=0;
				while ($row = mysqli_fetch_assoc($result)) {
					$c++;
					echo "<tr>";
					echo "<td>".$c."</td>";
					echo "<td>".$row['firstName']." ".$row['lastName']."</td>";
					
					echo "<td>".$row['salary']."</td>";
					echo "<td>".$row['allowance']."</td>";
					echo "<td>".$row['deduction']."</td>";
					echo "<td>".$row['total']."</td>";
					echo "<td>".$row['date']."</td>";
					
					
					//echo "<td><a href=\"emp_sal_print.php?sal_id=$row[sal_id]\">View</a>";
					echo "<td>"
					?>
<form action="emp_sal_print.php" method="post">
					<input type="hidden" name="sal_id" value="<?php echo $row['sal_id'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">Print</button></p>
				</form>
				<?php
				echo "</td>";
				}
			?>
			
			</table>
			</div>
</body>
</html>