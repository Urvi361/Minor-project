<?php 
	session_start();
?>



<html>
<head>
	<title>Employee Panel | Employee Managment System</title>
	
	<!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">

	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>XYZ Corp.</h1>
			<ul id="navli">
				<li><a class="homeblack" href="eloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="myprofile.php">My Profile</a></li>
				<li><a class="homeblack" href="empproject.php">My Projects</a></li>
				<li><a class="homered" href=".php">Submit project</a></li>
				<li><a class="homeblack" href="applyleave.php">Apply Leave</a></li>
				
				<li><a class="homeblack" href="elogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	
		 <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Submit Project Details</h2>
					<?php
					require_once ('process/dbh.php');
					//echo $eid = $_GET['eid'];
					$pid = $_GET['pid'];
					//die();
					$sql = "SELECT * FROM `project` where pid='$pid'";
					//die();
					$result = mysqli_query($conn, $sql);
					$row = mysqli_fetch_assoc($result);	
					?>
                    <form action="empinsertproject.php" method="POST" enctype="multipart/form-data">
					
					<input class="input--style-1" type="hidden"  name="pid" value="<?php echo $row['pid']; ?>">
                        
                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Project Name" name="pname" value="<?php echo $row['pname']; ?>">
                        </div>
                        <div class="input-group">
                            <input type="file" name="file" class="input--style-1" required="required">
                        </div>
                        
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit" name="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	
	 <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>
</body>
	
</html>