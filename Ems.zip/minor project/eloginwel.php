<?php 
session_start();
?>
<html>
<head>
	<title>Employee Panel | Employee Managment System</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
	<link href="menu.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
</head>
<body>
	
	<header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
	<div>

   
    	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Due Projects</h2>
       	<table>

			<tr>
				<th align = "center">Serial No.</th>
				<th align = "center">Project Name</th>
				<th align = "center">Due Date</th>
			</tr>
			<?php
			require_once ('process/dbh.php');
			$sql1 = "SELECT `pname`, `duedate` FROM `project` WHERE eid = '".$_SESSION['id']."' and pstatus = 'Due'";
			$resu = mysqli_query($conn, $sql1);
			$cnt=0;
				while ($employee1 = mysqli_fetch_assoc($resu)) {
					$cnt++;
					echo "<tr>";
					echo "<td>".$cnt."</td>";
					echo "<td>".$employee1['pname']."</td>";
					echo "<td>".$employee1['duedate']."</td>";

				}


			?>

		</table>



	<!--	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Salary Status</h2>
    	

    	<table>

			<tr>
				
				<th align = "center">Base Salary</th>
				<th align = "center">Allowance</th>
				<th align = "center">Deduction</th>
				<th align = "center">Total Salary</th>
				<th align = "center">Date</th>
				
			</tr>

			

			<?php
			require_once ('process/dbh.php');
			$sql3 = "SELECT * FROM `salary` WHERE id = '".$_SESSION['id']."'";
			$result3 = mysqli_query($conn, $sql3);
				while ($employee = mysqli_fetch_assoc($result3)) {
					
					echo "<tr>";
					echo "<td>".$employee['salary']."</td>";
					echo "<td>".$employee['allowance']."</td>";
					echo "<td>".$employee['deduction']."</td>";
					echo "<td>".$employee['total']."</td>";
					echo "<td>".$employee['date']."</td>";
					
				}
			?>
		</table>-->

		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Leave Satus</h2>
    	

    	<table>

			<tr>
				
				<th align = "center">Start Date</th>
				<th align = "center">End Date</th>
				<th align = "center">Total Days</th>
				<th align = "center">Reason</th>
				<th align = "center">Status</th>
			</tr>

			

			<?php
			require_once ('process/dbh.php');
			$query="Select start,end,reason,status From  employee_leave where (id='".$_SESSION['id']."')";
			//$query = "SELECT `pname`, `duedate`,`` FROM `project` WHERE id='".$_SESSION['id']."' and status = 'Due'";
			$res1 = mysqli_query($conn, $query);
				while ($employee = mysqli_fetch_assoc($res1)){
					$date1 = new DateTime($employee['start']);
					$date2 = new DateTime($employee['end']);
					$interval = $date1->diff($date2);
					$interval = $date1->diff($date2);

					echo "<tr>";
					
					
					echo "<td>".$employee['start']."</td>";
					echo "<td>".$employee['end']."</td>";
					echo "<td>".$interval->days."</td>";
					echo "<td>".$employee['reason']."</td>";
					echo "<td>".$employee['status']."</td>";
					
				}


				


			?>

		</table>




   
<br>
<br>
<br>
<br>
<br>







	</div>


		</h2>


		
		
	</div>
</body>
</html>