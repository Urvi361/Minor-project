<?php
session_start();
?>
<html>
<head>
	<title>Attendance Record |  Admin Panel | Employee managment system</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link rel="stylesheet" type="text/css" href="menu.css">
</head>
<body>
	<header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">View specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve leave</a>
					<a href="cancelleave.php">Cancel leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	
	
	
	<div class="divider"></div>
<div id="divimg">
<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Employee Attendance Record</h2>

		<table>
			<tr>
				<th align = "center">Number</th>
			<!--	<th align = "center">Picture</th>-->
				<th align = "center">Name</th>
				<th align = "center">Department</th>
				<th align = "center">Attendance</th>
				<th align = "center">Date</th>
				
			</tr>

			<?php
			require_once ('process/dbh.php');
			/*$sql ="select * from attendance as a
			left join employee as e on a.id = e.id where
			a.aid='".$_SESSION['id']."'";*/
			//$sql = "SELECT * FROM `employee_leave` WHERE start='2020-03-28'";
			$date = $_REQUEST['date'];
			//$attendance = $_REQUEST['attendance'];
			$sql ="select * from attendance as a
			left join employee as e on a.id = e.id
			where (a.aid='".$_SESSION['id']."' and a.date='$date')";
			$result = mysqli_query($conn, $sql);
			$cnt=0;
				while ($row = mysqli_fetch_assoc($result)) {
					$cnt++;
					echo "<tr>";
					echo "<td>".$cnt."</td>";
				
					//echo "<td><img src='process/".$row['pic']."' height = 60px width = 60px></td>";
					echo "<td>".$row['firstName']." ".$row['lastName']."</td>";
					echo "<td>".$row['dept']."</td>";
					echo "<td>".$row['attendance']."</td>";
					echo "<td>".$row['date']."</td>";
					//echo "<td><a href=\"attendance_edit.php?id=$row[atten_id]\">Edit</a> | <a href=\"attendance_delete.php?id=$row[atten_id]\">Delete</a></td>";

				}


			?>

		</table>
		</div>
	
</body>
</html>