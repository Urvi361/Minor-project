<?php
require_once ('process/dbh.php');
$pid = $_POST['pid'];
$date = date("Y-m-d");
$query = "update project set subdate = '$date' , pstatus='submitted' where pid='$pid'";
//die();
mysqli_query($query);
header("Location:empproject.php");
?>