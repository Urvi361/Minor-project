<?php
session_destroy();
header("Location:elogin.html");
?>
