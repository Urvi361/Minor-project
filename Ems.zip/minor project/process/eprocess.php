<?php
session_start();
require_once ('dbh.php');

$email = $_POST['mailuid'];
$password = $_POST['pwd'];

$sql = "SELECT * from `employee` WHERE email = '$email' and password = '$password' and status = 1";
//$sqlid = "SELECT id from `employee` WHERE email = '$email' AND password = '$password'";
//die();
$result = mysqli_query($conn, $sql);
//$id = mysqli_query($conn , $sqlid);
//$empid = "";
if($row = mysqli_fetch_assoc($result)){
   $_SESSION['id'] = $row['id'];
   $_SESSION['firstName'] = $row['firstName'];
 // $_SESSION['img_path']=$row['img_path'];
   $_SESSION['email'] = $row['email'];
  //echo $_SESSION['pic'] = $row['pic'];
 //die();
	header("Location: ..//eloginwel.php");
}
else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>