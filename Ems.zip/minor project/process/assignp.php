<?php
session_start();
require_once ('dbh.php');
$aid=$_SESSION['id'];
$pname = $_POST['pname'];
$eid = $_POST['eid'];
$subdate = $_POST['duedate'];
//$firstName = $_POST['firstName'];

$sql = "INSERT INTO `project`(`aid`, `eid`, `pname`, `duedate` , `pstatus`) VALUES ('$aid', '$eid' , '$pname' , '$subdate' , 'Due')";
//die();
$result = mysqli_query($conn, $sql);

if(($result) == 1){    
    header("Location: ..//assignproject.php");
}
else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Assign')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>