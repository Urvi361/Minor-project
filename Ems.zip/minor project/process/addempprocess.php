<?php
session_start();

require_once ('dbh.php');
$aid=$_SESSION['id'];
$firstname = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$gender = $_POST['gender'];
$dept = $_POST['dept'];
$degree = $_POST['degree'];
$base = $_POST['base'];
$birthday =$_POST['birthday'];
//echo "$birthday";
$files = $_FILES['file'];
$filename = $files['name'];
$filrerror = $files['error'];
$filetemp = $files['tmp_name'];
$fileext = explode('.', $filename);
$filecheck = strtolower(end($fileext));
$fileextstored = array('png' , 'jpg' , 'jpeg');

if(in_array($filecheck, $fileextstored)){

    $destinationfile = 'images/'.$filename;
    move_uploaded_file($filetemp, $destinationfile);

    $sql = "INSERT INTO `employee`(`id`, `aid`, `firstName`, `lastName`, `email`, `password`, `birthday`, `gender`, `contact`,  `address`, `dept`, `degree`, `pic`, `status`) VALUES ('','$aid','$firstname','$lastName','$email','1234','$birthday','$gender','$contact','$address','$dept','$degree','$destinationfile','1')";

$result = mysqli_query($conn, $sql);

$last_id = $conn->insert_id;

$sqlS = "INSERT INTO `basic_salary`(`aid`, `id`, `base`) VALUES ('$aid','$last_id','$base')";
$salaryQ = mysqli_query($conn, $sqlS);

if(($result) == 1){
    
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Registered')
    window.location.href='..//viewemp.php';
    </SCRIPT>");
    //header("Location: ..//aloginwel.php");
}

else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Registere')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

}
else{
$sql = "INSERT INTO `employee`(`id`, `firstName`, `lastName`, `email`, `password`, `birthday`, `gender`, `contact`,  `address`, `dept`, `degree`, `pic`, `status`) VALUES ('','$firstname','$lastName','$email','1234','$birthday','$gender','$contact','$address','$dept','$degree','images/no.jpg','1')";
$result = mysqli_query($conn, $sql);

$last_id = $conn->insert_id;
$sqlS = "INSERT INTO `basic_salary`(`aid`, `id`, `base`) VALUES ('$aid','$last_id','$base')";

$salaryQ = mysqli_query($conn, $sqlS);
if(($result) == 1){
    
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Succesfully Registered')
    window.location.href='..//viewemp.php';
    </SCRIPT>");
    //header("Location: ..//aloginwel.php");
}
// else{
//     echo ("<SCRIPT LANGUAGE='JavaScript'>
//     window.alert('Failed to Registere')
//     window.location.href='javascript:history.go(-1)';
//     </SCRIPT>");
// }
}
?>