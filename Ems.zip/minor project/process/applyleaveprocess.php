<?php
session_start();
//including the database connection file
require_once ('dbh.php');

//getting id of the data from url
$id = $_SESSION['id'];
$aid = $_POST['aid'];
//echo $id;
$reason = $_POST['reason'];
$start = $_POST['start'];
//echo "$reason";
$end = $_POST['end'];
$sql = "INSERT INTO `employee_leave`(`aid`, `id`,`token`, `start`, `end`, `reason`, `status`) VALUES ('$aid','$id','','$start','$end','$reason','Pending')";
//die();
$result = mysqli_query($conn, $sql);

//redirecting to the display page (index.php in our case)
header("Location:..//eloginwel.php");
?>

