<?php
session_start();
require_once ('dbh.php');

$email = $_POST['mailuid'];
$password = $_POST['pwd'];

$sql = "SELECT * from `alogin` WHERE email = '$email' AND password = '$password'";

//echo "$sql";

$result = mysqli_query($conn, $sql);

if($row = mysqli_fetch_assoc($result)){
	//echo ("logged in");
	$_SESSION['email'] = $email;
	$_SESSION['name'] = $row['name'];
	$_SESSION['id'] = $row['id'];
	
	//die();
	//exit;
	header("Location: ..//aloginwel.php");
}

else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>