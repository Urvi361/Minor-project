<?php
session_start();
require_once ('dbh.php');
$aid = $_SESSION['id'];
$id = $_POST['id'];
$attendance = $_POST['attendance'];
//$date = $_POST['date'];
$date = date('Y-m-d');
//$firstName = $_POST['firstName'];

$sql = "INSERT INTO `attendance`(`atten_id`, `aid`, `id`, `attendance`, `date`) VALUES (NULL, '$aid', '$id' , '$attendance' , '$date')";
//die();
$result = mysqli_query($conn, $sql);

if(($result) == 1){    
    header("Location: ..//attendance_view.php");
}
else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Assign')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>