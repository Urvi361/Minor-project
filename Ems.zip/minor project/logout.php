<?php
session_destroy();
header("Location:alogin.html");
?>