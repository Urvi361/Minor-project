<?php 
session_start();
?>

<html>
<head>
	<title>Apply Leave | Employee Panel | Employee Managment System</title>
	<link rel="stylesheet" type="text/css" href="styleapply.css">
	<link rel="stylesheet" type="text/css" href="menu.css">
</head>
<body>
	
	<header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
	 
	<div class="divider"></div>
	<div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Apply Leave Form</h2>
					<?php
					require_once ('process/dbh.php');
					$id = $_SESSION['id'];
					$sql = "SELECT aid from `employee` where id='$id'";
					$result = mysqli_query($conn, $sql);
					$row = mysqli_fetch_assoc($result)
					?>
                    <form action="process/applyleaveprocess.php" method="POST">


                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="Reason" name="reason">
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                            	<p>Start Date</p>
                                <div class="input-group">
                                    <input class="input--style-1" type="date" placeholder="start" name="start">
                                   
                                </div>
                            </div>
                            <div class="col-2">
                            	<p>End Date</p>
                                <div class="input-group">
                                    <input class="input--style-1" type="date" placeholder="end" name="end">
                                </div>
                            </div>
							 <input class="input--style-1" type="hidden" placeholder="end" name="aid" value="<?php echo $row['aid']; ?>">
                        </div>
                        <div class="p-t-20">
                            <button class="btn btn--radius btn--green" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

	<table>
			<tr>
				<th align = "center">Start Date</th>
				<th align = "center">End Date</th>
				<th align = "center">Total Days</th>
				<th align = "center">Reason</th>
				<th align = "center">Status</th>
			</tr>


			<?php
				require_once ('process/dbh.php');

				$sql = "select * from employee_leave  where id='".$_SESSION['id']."'";
				
				$res = mysqli_query($conn, $sql);
				while ($row = mysqli_fetch_assoc($res)){
					$date1 = new DateTime($row['start']);
					$date2 = new DateTime($row['end']);
					$interval = $date1->diff($date2);
					$interval = $date1->diff($date2);

					echo "<tr>";
					echo "<td>".$row['start']."</td>";
					echo "<td>".$row['end']."</td>";
					echo "<td>".$interval->days."</td>";
					echo "<td>".$row['reason']."</td>";
					echo "<td>".$row['status']."</td>";	
					echo "</tr>";
				}
			?>
		</table>
</body>
</html>