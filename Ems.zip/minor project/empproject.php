<?php 
	session_start();
?>



<html>
<head>
	<title>Employee Panel | Employee Managment System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	
	<link rel="stylesheet" type="text/css" href="menu.css">
	<?php
			 $rowperpage = 10;
            $row = 0;
            // Previous Button
            if(isset($_POST['but_prev'])){
                $row = $_POST['row'];
                $row -= $rowperpage;
                if( $row < 0 ){
                    $row = 0;
                }
            }
            // Next Button
            if(isset($_POST['but_next'])){
                $row = $_POST['row'];
                $allcount = $_POST['allcount'];

                $val = $row + $rowperpage;
                if( $val < $allcount ){
                    $row = $val;
                }
            }
		?>
</head>
<body>
	
	<header>
	<h1>Employee managment system</h1>
		<div class="navbar">
			
			<a href="eloginwel.php">Home</a>
			<div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="empproject.php">Project status</a>
					<!--<a href="assignproject.php"></a>-->
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="emp_salary_view.php">Payslip</a>
					
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="emp_viewattendance.php">View record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="applyleave.php">Apply Leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href="myprofile.php"><?php
							echo $_SESSION['firstName'];
							?></a>
					<a href="changepassemp.php">Change password</a>
					<a href="emplogout.php">Log out</a>
				  </div>
				</div>
		</div>
	</header>
	<div class="divider"></div>
	<div id="divimg">

<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Employee Project Details</h2>

		<table>
			<tr>

				<th align = "center">Serial No.</th>
				<th align = "center">Name</th>
				<th align = "center">Project Name</th>
				<th align = "center">Due Date</th>
				<th align = "center">Sub Date</th>
				
				<th align = "center">Status</th>
				<th align = "center">Option</th>
			</tr>

			<?php
				require_once ('process/dbh.php');
				$sql1 = "SELECT COUNT(id) AS cntrows FROM attendance where id='".$_SESSION['id']."'";
				$result1 = mysqli_query($conn,$sql1);
				$fetchresult = mysqli_fetch_array($result1);
				$allcount = $fetchresult['cntrows'];
				
				$sql ="select * from project as s
				left join employee as e on s.eid = e.id where 
				s.eid='".$_SESSION['id']."'";
				//$sql = "SELECT * FROM `project` where eid = '".$_SESSION['id']."'";
				$result = mysqli_query($conn, $sql);
				$cnt=0;
				while ($employee = mysqli_fetch_assoc($result)) {
				$cnt++;
				?>
					<tr>
					<td><?php echo $cnt; ?></td>
					
					<td><?php echo $employee['firstName'];?><?php $employee['lastName'];?></td>
					<td><?php echo $employee['pname'];?></td>
					<td><?php echo $employee['duedate'];?></td>
					<td><?php echo $employee['subdate'];?></td>
					<td><?php echo $employee['pstatus'];?></td>
					<!--<a href="psubmit.php?pid=<?php echo $employee['pid'];?>">Complete</a>-->

					 <td>
					 <?php
					if($employee["subdate"]=='0000-00-00')
					{
					?>
					<form action="psubmit.php" method="post">
					<input type="hidden" name="pid" value="<?php echo $employee['pid'];?>">
					<p><button name="submit" class="btn btn--radius btn--green">Complete</button></p>
					</form>
											
					<?php
					}
					?>
					 </td>
<?php
				}


			?>

		</table>
		</div>
 <form method="post" action="">
            <div id="div_pagination">
                <input type="hidden" name="row" value="<?php echo $row; ?>">
                <input type="hidden" name="allcount" value="<?php echo $allcount; ?>">
                <input type="submit" class="button" name="but_prev" value="Previous">
                <input type="submit" class="button" name="but_next" value="Next">
            </div>
        </form>
		</body>
</html>