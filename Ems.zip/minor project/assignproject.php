<?php
session_start();
?>



<html>
<head>
	<title>Project Status |  Admin Panel</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link rel="stylesheet" type="text/css" href="menu.css" media="all">
	<?php
			 $rowperpage = 10;
            $row = 0;
            // Previous Button
            if(isset($_POST['but_prev'])){
                $row = $_POST['row'];
                $row -= $rowperpage;
                if( $row < 0 ){
                    $row = 0;
                }
            }
            // Next Button
            if(isset($_POST['but_next'])){
                $row = $_POST['row'];
                $allcount = $_POST['allcount'];

                $val = $row + $rowperpage;
                if( $val < $allcount ){
                    $row = $val;
                }
            }
		?>
</head>
<body>
	<header>
<h1>Employee Managment System</h1>
<div class="navbar">
  <a href="aloginwel.php">Home</a>
<div class="dropdown">
				  <button class="dropbtn">Employee</button>
				  <div class="dropdown-content">
					<a href="addemp.php">Add Employee</a>
					<a href="viewemp.php">View Record</a>
				  </div>
				</div>
  <div class="dropdown">
				  <button class="dropbtn">Project</button>
				  <div class="dropdown-content">
					<a href="assign.php">Assign Project</a>
					<a href="assignproject.php">Project status</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Salary</button>
				  <div class="dropdown-content">
					<a href="addsalary.php">Payslip</a>
					<a href="salaryemp.php">View record</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Attendance</button>
				  <div class="dropdown-content">
					<a href="attendanceinsert.php">Add attendance</a>
					<a href="attendance_view.php">View record</a>
					<a href="atten_spec.php">View specific record</a>
				  </div>
				</div>
				
				<div class="dropdown">
				  <button class="dropbtn">Leave</button>
				  <div class="dropdown-content">
					<a href="empleave.php">View record</a>
					<a href="approveleave.php">Approve leave</a>
					<a href="cancelleave.php">Cancel leave</a>
				  </div>
				</div>
				<div class="dropdown">
				  <button class="dropbtn">Settings</button>
				  <div class="dropdown-content">
					<a href=""><?php
							echo $_SESSION['name'];
							?></a>
					<a href="changepassadmin.php">Change password</a>
					<a href="logout.php">Log out</a>
				  </div>
				</div>
</div>

		
	</header>
	 
	
	<div class="divider"></div>
	<div id="divimg">
<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Assign Project Details</h2>
    	
		<table>
			<tr>

				<!--<th align = "center">Project ID</th>
				<th align = "center">Emp. ID</th>-->
				<th align = "center">Serial No.</th>
				<th align = "center">Employee Name</th>
				<th align = "center">Project Name</th>
				<th align = "center">Due Date</th>
				<th align = "center">Submission Date</th>
				<th align = "center">Status</th>
				<!--<th align = "center">Option</th>-->
				
			</tr>

			<?php
			require_once ('process/dbh.php');
			
		/*	$sql1 = "SELECT COUNT(pid) AS cntrows FROM project where aid='".$_SESSION['id']."'";
            $result1 = mysqli_query($conn,$sql1);
            $fetchresult = mysqli_fetch_array($result1);
            $allcount = $fetchresult['cntrows'];  desc limit $row,".$rowperpage*/
			
			
			//$aid = $_SESSION['id'];
			$sql ="select * from project as s
			left join employee as e on s.eid = e.id where 
			s.aid='".$_SESSION['id']."' order by subdate";
			//$sql = "SELECT * from `project` where aid='$aid' order by subdate desc";
			$result = mysqli_query($conn, $sql);
//mysqli_num_rows
					$sno = 0;
				while ($employee = mysqli_fetch_assoc($result)) {
					$sno++;
					echo "<tr>";
					echo "<td>".$sno."</td>";
				//	echo "<td>".$employee['eid']."</td>";
				echo "<td>".$employee['firstName']." ".$employee['lastName']."</td>";
					echo "<td>".$employee['pname']."</td>";
					echo "<td>".$employee['duedate']."</td>";
					echo "<td>".$employee['subdate']."</td>";
					
					echo "<td>".$employee['pstatus']."</td>";
				//	echo "<td><a href=\"mark.php?id=$employee[eid]&pid=$employee[pid]\">Mark</a>"; 

				}


			?>

		</table>
		</div>
	<!--	 <form method="post" action="">
            <div id="div_pagination">
                <input type="hidden" name="row" value="<?php echo $row; ?>">
                <input type="hidden" name="allcount" value="<?php echo $allcount; ?>">
                <input type="submit" class="button" name="but_prev" value="Previous">
                <input type="submit" class="button" name="but_next" value="Next">
            </div>
        </form>-->
	
</body>
</html>